import json, os
import cadquery as cq
from rounded import STYLES, body, halves, lid, bezel, clona, boss_positions
from model import lista

OUT = "/home/claude/viewer2"
os.makedirs(OUT + "/stl", exist_ok=True)
BED = (250, 210, 220)
man = {}

def exp(key, name, shape, color, explode, label):
    fn = f"{key}_{name}.stl"
    cq.exporters.export(shape, f"{OUT}/stl/{fn}", tolerance=0.05, angularTolerance=0.12)
    bb = shape.val().BoundingBox()
    d = sorted([bb.xlen, bb.ylen, bb.zlen], reverse=True)
    fits = d[0] <= BED[0] and d[1] <= BED[1] and d[2] <= BED[2]
    valid = shape.val().isValid()
    man.setdefault(key, []).append(dict(file=fn, color=color, explode=explode, label=label,
        size=[round(bb.xlen, 1), round(bb.ylen, 1), round(bb.zlen, 1)], fits=fits, valid=valid,
        volume=round(shape.val().Volume() / 1000, 1)))

for key, s in STYLES.items():
    s = dict(s, key=key)
    b = body(s)
    L, R = halves(b)
    exp(key, "telo_L", L, "#2b2d31", [-45, 0, 0], "Tělo – levá polovina")
    exp(key, "telo_P", R, "#2b2d31", [45, 0, 0], "Tělo – pravá polovina")
    exp(key, "ramecek", bezel(s), "#e8692c", [0, 0, 45], "Rámeček displeje s panty")
    lL, lR = lid(s)
    exp(key, "viko_L", lL, "#3a3d43", [-45, 0, -60], "Víko – levé")
    exp(key, "viko_P", lR, "#3a3d43", [45, 0, -60], "Víko – pravé")
    cl = clona(s).mirror("XZ").rotate((0, 0, 0), (1, 0, 0), 90).translate((0, 62.5, 94))
    exp(key, "clona", cl, "#4a4e55", [0, 0, 70], "Sluneční clona")
    li = lista()
    exp(key, "lista_1", li.translate((0, -48, 38)), "#6b7078", [0, 0, -28], "Přítlačná lišta 1")
    exp(key, "lista_2", li.translate((0, 58, 38)), "#6b7078", [0, 0, -28], "Přítlačná lišta 2")
    print(key, "bosses", [tuple(round(v, 1) for v in p) for p in boss_positions(s["R"])][:1])

json.dump(man, open(f"{OUT}/manifest_full.json", "w"), indent=1, ensure_ascii=False)
for k, v in man.items():
    print(k)
    for p in v:
        print("  ", p["label"], p["size"], "fits" if p["fits"] else "NO FIT", "valid" if p["valid"] else "INVALID", p["volume"], "cm3")
