# Shade v2: top plate (friction hinge) + two bezel-hinged side doors with tabs + slide-pin locks.
# Everything modelled in the CLOSED (transport) position.
import cadquery as cq
from model import box, cyl, T, D, DISP_W, DISP_H, DISP_Y, EAR_X, EAR_Y0, EAR_Y1, SW_X, SW_Y, SW_D, INSERT_D
from rounded import BEZ_HOLES, BEZ_BOSS_D

HY, HZ = 54.5, 70.0                 # main hinge axis (along X)
PX, PY0, PY1 = 104.0, -48.0, 49.0   # shortened: room for the main anchor below the display   # plate extent
PZ0, PT = 66.0, 3.0                 # plate sits above the closed doors
DAX, DAZ = 99.0, 62.0               # door hinge axes: vertical (along Y) at x=±99, z=62
DT = 3.0                            # door thickness
DY0, DY1 = -40.0, 50.0              # door height range
DDEPTH = 95.0 
DOOR_PLANE = DAX - 2.0          # open door mid-plane x (door offset 2 mm from the hinge axis)
                      # door depth (closed: covers half the display)
TAB_D0, TAB_D1 = 75.0, 85.0         # tab position along the door depth
TAB_TOP = 58.5                      # tab top (open: 5 mm above plate top)
PIN_Y_OPEN = 56.0
MAG = []   # magnets removed on request – the friction hinge holds the closed plate
BEZ_KNUCKLES = [(-40, -31), (-15, 15), (31, 40)]
DOOR_KNUCKLES = [(-30.5, -15.5), (15.5, 30.5)]


def _zw(depth):        # world z of a door point at given depth when open
    return DAZ + depth


def _plate_y(zw):      # plate (closed) y of a point that is at world z when plate is open at -90°
    return HY - (zw - HZ)


def bezel2(s):
    X, Y0, t = 100.0, -72.0, 3.0   # extended down to carry the main anchor
    Y1 = min(75.0, 80.0 - s["RF"] - 0.5)
    z0 = D
    bz = box(-X, X, Y0, Y1, z0, z0 + t).edges("|Z").fillet(s["RZ"]).edges(">Z").fillet(1.5)
    for sx in (1, -1):
        ear = box(sx*EAR_X - 2, sx*EAR_X + 2, EAR_Y0, EAR_Y1, z0 + t - 0.5, HZ + 4)
        bz = bz.union(ear.edges("|X").edges(">Z").fillet(1.9))
        gus = (cq.Workplane("YZ").polyline([(EAR_Y1 - 0.5, z0 + t - 0.5), (EAR_Y1 + 5.0, z0 + t - 0.5), (EAR_Y1 - 0.5, z0 + t + 8)])
               .close().extrude(4.0).translate((sx*EAR_X - 2, 0, 0)))
        bz = bz.union(gus)
        # door hinge knuckles + web down to the bezel
        for (y0, y1) in BEZ_KNUCKLES:
            bz = bz.union(cyl(7, y1 - y0, sx*DAX, y0, DAZ, axis="y"))
            bz = bz.union(box(min(sx*95.5, sx*DAX), max(sx*95.5, sx*DAX), y0, y1, z0 + t - 0.5, DAZ))
        bz = bz.cut(cyl(2.0, 100, sx*DAX, -50, DAZ, axis="y"))
    # magnet posts for the closed plate
    for (x, y) in MAG:
        bz = bz.union(cyl(10, PZ0 - 0.5 - (z0 + t) + 0.5, x, y, z0 + t - 0.5))
        bz = bz.cut(cyl(6.2, 3.2, x, y, PZ0 - 0.5 - 3.2 + 0.01))
    win = box(-DISP_W/2, DISP_W/2, DISP_Y - DISP_H/2, DISP_Y + DISP_H/2, z0 - 1, z0 + t + 1).edges("|Z").fillet(2)
    bz = bz.cut(win)
    bz = bz.cut(cyl(3.4, 200, -100, HY, HZ, axis="x"))
    for sx in (1, -1):
        bz = bz.cut(cyl(SW_D, t + 2, sx*SW_X, SW_Y, z0 - 1))
    for (x, y) in BEZ_HOLES:
        bz = bz.cut(cyl(3.4, t + 2, x, y, z0 - 1))                                  # M3 button-head screw from the front
    return bz


def plate2(s):
    p = box(-PX, PX, PY0, PY1, PZ0, PZ0 + PT).edges("|Z").fillet(s["RZ"]).edges(">Z").fillet(1.2)
    for sx in (1, -1):
        arm = box(sx*83.6 - 2, sx*83.6 + 2, PY1 - 6, HY + 4, PZ0, HZ + 4).edges("|X").edges(">Y").fillet(3.9)
        p = p.union(arm)
        # slot for the door tab (open state)
        ys = sorted([_plate_y(_zw(TAB_D0)), _plate_y(_zw(TAB_D1))])
        p = p.cut(box(sx*DOOR_PLANE - 1.8, sx*DOOR_PLANE + 1.8, ys[0] - 0.4, ys[1] + 0.4, PZ0 - 1, PZ0 + PT + 1))
        # slide-lock guide block on the outer face
        yc = _plate_y(_zw((TAB_D0 + TAB_D1) / 2))
        x0, x1 = sorted([sx*82.0, sx*95.0])
        blk = box(x0, x1, yc - 6, yc + 6, PZ0 + PT - 0.5, PZ0 + PT + 6).edges("|X").fillet(2)
        blk = blk.cut(cyl(3.3, x1 - x0 + 2, x0 - 1, yc, HZ + (PIN_Y_OPEN - HY), axis="x"))
        blk = blk.cut(box(min(sx*84.2, sx*97), max(sx*84.2, sx*97), yc - 2.8, yc + 2.8, PZ0 + PT - 0.01, PZ0 + PT + 7))  # knob slot
        p = p.union(blk)
    p = p.cut(cyl(3.4, 200, -100, HY, HZ, axis="x"))
    for (x, y) in MAG:
        p = p.cut(cyl(6.2, 3.2, x, y, PZ0 - 0.01))
    return p


def door(sx, s):
    z0, z1 = DAZ - 3.5, DAZ - 3.5 + DT          # door underside flush with the knuckle bottom
    x_in = sx*(DAX - DDEPTH)
    xa, xb = sorted([x_in, sx*(DAX - 4.2)])
    d = box(xa, xb, DY0, DY1, z0, z1)
    d = d.edges("|Z").edges(">X" if sx < 0 else "<X").fillet(s["RZ"])     # rounded free corners
    # tab on the top edge
    ta, tb = sorted([sx*(DAX - TAB_D1), sx*(DAX - TAB_D0)])
    tab = box(ta, tb, DY1 - 1, TAB_TOP, z0, z1).edges("|Z").edges(">Y").fillet(2)
    d = d.union(tab)
    d = d.cut(cyl(3.4, 10, sx*(DAX - (TAB_D0 + TAB_D1)/2), PIN_Y_OPEN, z0 - 1))
    for (y0, y1) in DOOR_KNUCKLES:
        d = d.union(cyl(7, y1 - y0, sx*DAX, y0, DAZ, axis="y"))
        wa, wb = sorted([sx*(DAX - 5), sx*DAX])
        d = d.union(box(wa, wb, y0, y1, z0, z1))
    d = d.cut(cyl(2.2, 100, sx*DAX, -50, DAZ, axis="y"))
    return d


KNOB_X = 87.0


def pin(sx):
    """Printed slide knob in RETRACTED position; carries a 3x14 mm steel dowel (see dowel())."""
    yc = _plate_y(_zw((TAB_D0 + TAB_D1) / 2))
    zc = HZ + (PIN_Y_OPEN - HY)
    post = box(sx*KNOB_X - 2.5, sx*KNOB_X + 2.5, yc - 2.5, yc + 2.5, PZ0 + PT, PZ0 + PT + 11)
    cap = box(sx*KNOB_X - 5, sx*KNOB_X + 5, yc - 5, yc + 5, PZ0 + PT + 8, PZ0 + PT + 11).edges("|Z").fillet(2.5).edges(">Z").fillet(1)
    k = post.union(cap)
    return k.cut(cyl(2.9, 10, sx*KNOB_X - 5, yc, zc, axis="x"))


def dowel(sx):
    yc = _plate_y(_zw((TAB_D0 + TAB_D1) / 2))
    zc = HZ + (PIN_Y_OPEN - HY)
    a, b = sorted([sx*(KNOB_X - 6), sx*(KNOB_X + 8)])
    return cyl(3.0, b - a, a, yc, zc, axis="x")


PIN_TRAVEL = 5.5   # knob slides this far outward; dowel tip passes through the tab
