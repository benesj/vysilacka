import json, os, cadquery as cq
from rounded import STYLES, body, bezel
from shade import plate, flap, HINGE_Y, HINGE_Z, FLAP_AX, FLAP_AZ, MAG_PTS, MAG_D, MAG_H
from model import cyl
OUT="/home/claude/viewer2/stl"; man=json.load(open("/home/claude/viewer2/manifest_full.json"))
def exp(key,name,shape):
    cq.exporters.export(shape,f"{OUT}/{key}_{name}.stl",tolerance=0.05,angularTolerance=0.12)
    bb=shape.val().BoundingBox(); return [round(bb.xlen,1),round(bb.ylen,1),round(bb.zlen,1)], shape.val().isValid()
res={}
for key,s in [('S2',STYLES['S2'])]:
    s=dict(s,key=key)
    bz=bezel(s)
    for (x,y) in MAG_PTS: bz=bz.cut(cyl(MAG_D,MAG_H,x,y,58-MAG_H+0.01))
    r={}
    r["ramecek"]=exp(key,"ramecek",bz)
    pk=plate(s,False); r["klapka"]=exp(key,"klapka",pk)
    pc=plate(s,True); r["kapuce"]=exp(key,"kapuce",pc)
    fl=flap(-1); fr=flap(1)
    r["bocnice_L"]=exp(key,"bocnice_L",fl); r["bocnice_P"]=exp(key,"bocnice_P",fr)
    res[key]=r
    # replace bezel entry size in manifest
    for p in man[key]:
        if p["file"]==f"{key}_ramecek.stl": p["size"]=r["ramecek"][0]
    if key=="S2":
        b=body(s)
        def vol(a,b_):
            try: return round(a.intersect(b_).val().Volume(),2)
            except Exception: return 0.0
        print("closed  plate∩bezel",vol(pc,bz),"plate∩body",vol(pc,b),"flapL∩plate",vol(fl,pc),"flapR∩plate",vol(fr,pc))
        ax=((0,HINGE_Y,HINGE_Z),(1,HINGE_Y,HINGE_Z))
        po=pc.rotate(*ax,-100)
        # open flaps: rotate about own axis first, then with plate
        flo=fl.rotate((-FLAP_AX,0,FLAP_AZ),(-FLAP_AX,1,FLAP_AZ),90).rotate(*ax,-100)
        fro=fr.rotate((FLAP_AX,0,FLAP_AZ),(FLAP_AX,1,FLAP_AZ),-90).rotate(*ax,-100)
        print("open    plate∩bezel",vol(po,bz),"plate∩body",vol(po,b),"flapL∩body",vol(flo,b),"flapL∩bezel",vol(flo,bz),"flapR∩plate",vol(fro,po))
        bb=fro.val().BoundingBox(); print("open flapR bbox y",round(bb.ymin,1),round(bb.ymax,1),"z",round(bb.zmin,1),round(bb.zmax,1),"x",round(bb.xmin,1),round(bb.xmax,1))
json.dump(man,open("/home/claude/viewer2/manifest_full.json","w"),indent=1,ensure_ascii=False)
json.dump(res,open("/home/claude/viewer2/shade_sizes.json","w"))
print(json.dumps(res["S2"]))
