Parametricky model (Python + CadQuery 2.x).
Instalace: pip install cadquery trimesh
Spusteni:  python final_build.py   -> postavi vsechny dily, zkontroluje kolize (zavrene/otevrene stinitko,
           mezipolohy) a vyexportuje STL/STEP.
           python plates.py        -> rozmisti dily na tiskove desky MK4 a vyexportuje 3MF.
Hlavni rozmery: model.py (puvodni parametry z FreeCAD makra), rounded.py (zaobleni), shade2.py (stinitko),
internals.py (montazni mrizka na viku), harness3.py (uchyty na klicenky).
Pozn.: cesty k souborum ve skriptech jsou absolutni (/home/claude/...), pri spusteni jinde je uprav.
