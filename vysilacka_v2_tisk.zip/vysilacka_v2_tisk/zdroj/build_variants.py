import json, os
import cadquery as cq
from model import *

OUT = "/home/claude/viewer/parts"
os.makedirs(OUT, exist_ok=True)
BED = (250, 210, 220)  # Prusa MK4

manifest = {}


def export(variant, name, shape, color, explode, label, role):
    fn = f"{variant}_{name}.stl"
    cq.exporters.export(shape, os.path.join(OUT, fn), tolerance=0.08, angularTolerance=0.15)
    bb = shape.val().BoundingBox()
    dims = sorted([bb.xlen, bb.ylen, bb.zlen], reverse=True)
    # fits if the two largest dims fit the bed footprint and the smallest fits height (any orientation)
    fits = (dims[0] <= BED[0] and dims[1] <= BED[1] and dims[2] <= BED[2])
    manifest.setdefault(variant, []).append(dict(file=fn, color=color, explode=explode, label=label,
        role=role, size=[round(bb.xlen, 1), round(bb.ylen, 1), round(bb.zlen, 1)], fits=fits))


BODY = "#2b2d31"; ACC = "#e8692c"; LID = "#3a3d43"; MISC = "#5b6068"

# ---------------- Variant A: centre split ----------------
b = body()
L, R = split_body(b, [0.0])
export("A", "telo_L", L, BODY, [-45, 0, 0], "Tělo – levá polovina", "body")
export("A", "telo_P", R, BODY, [45, 0, 0], "Tělo – pravá polovina", "body")
for i, p in enumerate(lid_pieces([0.0])):
    export("A", f"viko_{i}", p, LID, [(-45 if i == 0 else 45), 0, -60], f"Víko – {'levé' if i == 0 else 'pravé'}", "lid")

# ---------------- Variant B: 3 modules ----------------
b = body()
cfg = {0: dict(front_top=None), 1: dict(front_top=None)}
pcs = split_body(b, [-94.0, 94.0], rib_cfg=cfg)
names = [("kridlo_L", "Gimbalový modul – levý", ACC, [-70, 0, 0]),
         ("stred", "Středový modul (displej)", BODY, [0, 0, 0]),
         ("kridlo_P", "Gimbalový modul – pravý", ACC, [70, 0, 0])]
for p, (n, lab, col, ex) in zip(pcs, names):
    export("B", n, p, col, ex, lab, "body")
for i, p in enumerate(lid_pieces([-94.0, 94.0])):
    export("B", f"viko_{i}", p, LID, [[-70, 0, 0][0] if i == 0 else (0 if i == 1 else 70), 0, -60], f"Víko – díl {i+1}", "lid")

# ---------------- Variant C: centre split + display bezel ----------------
b = bezel_holes_in_body(body(with_ears=False))
L, R = split_body(b, [0.0])
export("C", "telo_L", L, BODY, [-45, 0, 0], "Tělo – levá polovina", "body")
export("C", "telo_P", R, BODY, [45, 0, 0], "Tělo – pravá polovina", "body")
export("C", "ramecek", bezel(), ACC, [0, 0, 45], "Rámeček displeje s panty", "bezel")
for i, p in enumerate(lid_pieces([0.0])):
    export("C", f"viko_{i}", p, LID, [(-45 if i == 0 else 45), 0, -60], f"Víko – {'levé' if i == 0 else 'pravé'}", "lid")

# shared parts (sun shade sits on the hinge, open; strips behind display)
# deployed hood: plate sticks out from the panel above the display, wings hang down
cl = clona().mirror("XZ").rotate((0, 0, 0), (1, 0, 0), 90).translate((0, 62.5, 91))
cq.exporters.export(cl, os.path.join(OUT, "clona.stl"), tolerance=0.08, angularTolerance=0.15)
li = lista()
cq.exporters.export(li.translate((0, -48, 38)), os.path.join(OUT, "lista_1.stl"), tolerance=0.08, angularTolerance=0.15)
cq.exporters.export(li.translate((0, 58, 38)), os.path.join(OUT, "lista_2.stl"), tolerance=0.08, angularTolerance=0.15)

json.dump(manifest, open(os.path.join(OUT, "manifest.json"), "w"), indent=1, ensure_ascii=False)
for v, ps in manifest.items():
    print(v)
    for p in ps:
        print("  ", p["label"], p["size"], "OK" if p["fits"] else "NEVEJDE SE")
