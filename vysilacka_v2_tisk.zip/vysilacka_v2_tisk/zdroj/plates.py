import trimesh, numpy as np, json, os
from trimesh.transformations import rotation_matrix as R
V6='/home/claude/viewer6/stl/'; ST='/home/claude/vysilacka_v2_tisk/STL/'
rot={'x180':R(np.pi,[1,0,0]),'x-90':R(-np.pi/2,[1,0,0]),'y90':R(np.pi/2,[0,1,0]),'y-90':R(-np.pi/2,[0,1,0]),'none':np.eye(4)}
P={1:('telo_L','01_telo_leva_ASA','x180','#2b2d31'),2:('telo_P','02_telo_prava_ASA','x180','#2b2d31'),3:('ramecek','03_ramecek_displeje_ASA','none','#e8692c'),
 4:('viko_L','04_viko_leve_ASA','none','#3a3d43'),5:('viko_P','05_viko_prave_ASA','none','#3a3d43'),6:('deska','06_stinitko_deska_ASA','none','#4a4e55'),
 7:('lista_1','07_lista_displeje_A_ASA','none','#6b7078'),8:('lista_2','08_lista_displeje_B_ASA','none','#6b7078'),
 9:('dvirka_L','09_dvirka_leva_ASA','none','#5a5f67'),10:('dvirka_P','10_dvirka_prava_ASA','none','#5a5f67'),
 11:('knof_L','11_knoflik_soupatka_L_ASA','x180','#c9ccd1'),12:('knof_P','12_knoflik_soupatka_P_ASA','x180','#c9ccd1'),
 13:('uchyt_HL','13_uchyt_bocni_levy_ASA','none','#e8692c'),14:('uchyt_HP','14_uchyt_bocni_pravy_ASA','none','#e8692c'),
 15:('uchyt_H','15_uchyt_hlavni_pod_displejem_ASA','none','#e8692c'),16:('opera','16_operka_TPU','x-90','#1b1c1e')}
PLATES={1:[(1,8,25),(13,188,40),(14,188,66),(15,194,95),(11,192,130),(12,214,130)],
        2:[(2,42.5,25)],3:[(4,42.5,25)],4:[(5,42.5,25)],5:[(3,22.5,31.75)],
        6:[(6,21,15),(7,17,135),(8,17,165)],7:[(9,20,55.75),(10,131.5,55.75)],8:[(16,20,87)]}
def placed(m,x,y):
    b=m.bounds; m.apply_translation([x-b[0][0],y-b[0][1],-b[0][2]]); return m
recs=[]; ok=True
os.makedirs('/home/claude/vysilacka_v2_tisk/3MF',exist_ok=True)
for pl,items in PLATES.items():
    scene=trimesh.Scene(); bb=[]
    for (n,x,y) in items:
        key,fn,r,col=P[n]
        m=trimesh.load(V6+key+'.stl'); m.apply_transform(rot[r]); m=placed(m,x,y); m.merge_vertices()
        recs.append({"plate":pl,"n":n,"color":col,"v":np.round(m.vertices,2).ravel().tolist(),"i":m.faces.ravel().tolist()})
        hm=placed(trimesh.load(ST+fn+'.stl'),x,y); scene.add_geometry(hm,node_name=fn,geom_name=fn); bb.append(hm.bounds)
    for i in range(len(bb)):
        for j in range(i+1,len(bb)):
            a,c=bb[i],bb[j]
            if a[0][0]<c[1][0] and c[0][0]<a[1][0] and a[0][1]<c[1][1] and c[0][1]<a[1][1]: print('OVERLAP',pl); ok=False
    b=np.array(bb); mn=b[:,0,:].min(0); mx=b[:,1,:].max(0)
    if mn[0]<0 or mn[1]<0 or mx[0]>250 or mx[1]>210: print('OUT',pl,mn,mx); ok=False
    scene.export(f'/home/claude/vysilacka_v2_tisk/3MF/deska_{pl}.3mf')
open('/home/claude/viewer7/meshes.json','w').write('[\n'+',\n'.join(json.dumps(r,separators=(',',':')) for r in recs)+'\n]')
print('plates OK' if ok else 'PLATE PROBLEMS')
