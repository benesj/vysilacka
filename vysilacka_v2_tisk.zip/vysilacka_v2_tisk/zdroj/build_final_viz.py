import json, os, cadquery as cq, trimesh, numpy as np
from rounded import STYLES, body, halves
from shade2 import *
from internals import lid_with_internals, grid_points, LOOPS
from model import lista
s=dict(STYLES['S2'],key='S2')
OUT='/home/claude/viewer4'; os.makedirs(OUT+'/stl',exist_ok=True)
b=body(s); L,R=halves(b); lL,lR=lid_with_internals(s)
parts={'telo_L':L,'telo_P':R,'ramecek':bezel2(s),'viko_L':lL,'viko_P':lR,'deska':plate2(s),
       'dvirka_L':door(-1,s),'dvirka_P':door(1,s),'sou_L':pin(-1),'sou_P':pin(1),
       'lista_1':lista().translate((0,-48,38)),'lista_2':lista().translate((0,58,38))}
info={}
for k,o in parts.items():
    v=o.val(); bb=v.BoundingBox()
    info[k]=dict(valid=v.isValid(),solids=len(o.solids().vals()),size=[int(round(x)) for x in (bb.xlen,bb.ylen,bb.zlen)])
    cq.exporters.export(o,f'{OUT}/stl/{k}.stl',tolerance=0.05,angularTolerance=0.12)
print(json.dumps(info))
print('grid bosses',len(grid_points(s)),'loops',len(LOOPS))
def V(a,c):
    try: return round(a.intersect(c).val().Volume(),1)
    except Exception: return 0.0
print('lid∩body', V(lL.union(lR), b), 'lidL∩lidR', V(lL,lR))
recs=[]
for k in parts:
    m=trimesh.load(f'{OUT}/stl/{k}.stl'); m.merge_vertices()
    recs.append({"file":k,"v":np.round(m.vertices,2).ravel().tolist(),"i":m.faces.ravel().tolist()})
open(f'{OUT}/meshes.json','w').write('[\n'+',\n'.join(json.dumps(r,separators=(',',':')) for r in recs)+'\n]')
print(os.path.getsize(f'{OUT}/meshes.json')/1e6,'MB')
