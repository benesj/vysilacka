import cadquery as cq
from rounded import STYLES, body, halves
from shade2 import *
from internals import lid_with_internals
from harness import *
s=dict(STYLES['S2'],key='S2')
b=body_mods(body(s)); L,R=halves(b); lL,lR=lid_with_internals(s)
bz=bezel2(s); pl=plate2(s); dL=door(-1,s); dR=door(1,s)
kL,kR=pin(-1),pin(1); wL,wR=dowel(-1),dowel(1)
eye=top_eye_fixed(); aL,aR=anchor(-1),anchor(1); rest=tpu_rest()
parts=dict(telo_L=L,telo_P=R,viko_L=lL,viko_P=lR,ramecek=bz,deska=pl,dvirka_L=dL,dvirka_P=dR,knof_L=kL,knof_P=kR,oko=eye,uchyt_L=aL,uchyt_P=aR,opera=rest)
for k,o in parts.items():
    v=o.val(); print(k,'valid',v.isValid(),'solids',len(o.solids().vals()))
def V(a,c):
    try: return round(a.intersect(c).val().Volume(),2)
    except Exception: return 0.0
fixed=L.union(R).union(bz).union(lL).union(lR).union(eye).union(aL).union(aR).union(rest)
print('static pairs:', {n:V(x,y) for n,(x,y) in dict(bz_body=(bz,L.union(R)),eye_body=(eye,L.union(R)),anch_body=(aR,L.union(R)),rest_body=(rest,L.union(R)),lid_body=(lL.union(lR),L.union(R))).items()})
H_=((0,HY,HZ),(1,HY,HZ))
def doors(a): return dL.rotate((-DAX,0,DAZ),(-DAX,1,DAZ),-a), dR.rotate((DAX,0,DAZ),(DAX,1,DAZ),a)
def shade(a,t):
    asm=[pl, kL.translate((-t,0,0)), kR.translate((t,0,0)), wL.translate((-t,0,0)), wR.translate((t,0,0))]
    return [x.rotate(*H_,a) for x in asm]
bad=False
for tag,pa,da,t in [('closed',0,0,0),('up',-130,0,0),('d45',-130,45,0),('d90',-130,90,0),('down110',-110,90,0),('down100',-100,90,0),('final',-90,90,0),('locked',-90,90,PIN_TRAVEL)]:
    sh=shade(pa,t); Ld,Rd=doors(da)
    r={'P_fix':V(sh[0],fixed),'L_fix':V(Ld,fixed),'R_fix':V(Rd,fixed),'P_R':V(sh[0],Rd),'P_L':V(sh[0],Ld),
       'knob_R':V(sh[2],Rd),'dowel_R':V(sh[4],Rd),'dowel_P':V(sh[4],sh[0]),'knob_P':V(sh[2],sh[0]),'knob_fix':V(sh[2],fixed)}
    nz={k:v for k,v in r.items() if v>0}; print(tag, nz or 'OK'); bad|=bool(nz)
# does the dowel actually pass through the tab hole when locked?
sh=shade(-90,PIN_TRAVEL); Ld,Rd=doors(90)
bbw=sh[4].val().BoundingBox(); bbt=Rd.val().BoundingBox()
print('dowel x',round(bbw.xmin,1),round(bbw.xmax,1),' door plane x',round(bbt.xmin,1),round(bbt.xmax,1))
print('ALL CLEAR' if not bad else 'COLLISIONS')
