# Harness v2: two D-ring anchors at the upper side corners (neck strap V) + one bottom-centre D-ring anchor (waist belt).
import cadquery as cq
from model import box, cyl, W, H, T, D

TOP = H/2
SIDE_Y, SIDE_Z = 53.0, 27.0           # side anchor centre (above the slider slot y<=45, inside flat wall y<=60)
SIDE_SCREWS_Z = (SIDE_Z - 14.0, SIDE_Z + 14.0)
BOT_SCREWS = [(sx*3.0, z) for sx in (1, -1) for z in (20.0, 34.0)]   # into the bottom seam ribs
BOT_Z = 26.0
REST_Z0, REST_Z1 = 8.0, 44.0
REST_X0, REST_X1 = 25.0, 105.0
REST_SCREWS = [(sx*65.0) for sx in (1, -1)]


def _ycyl(d, h, x, y0, z):
    return cq.Workplane("XZ").circle(d/2).extrude(-h).translate((x, y0, z))


def _xcyl(d, h, x0, y, z):
    return cq.Workplane("YZ").circle(d/2).extrude(h).translate((x0, y, z))


def _zcyl(d, h, x, y, z0):
    return cq.Workplane("XY").circle(d/2).extrude(h).translate((x, y, z0))


def side_anchor(sx):
    """Base on the side wall, clevis ears perpendicular to Z, steel pin along Z, D-ring swings in the X-Y plane."""
    xw = sx*W/2
    xa, xb = sorted([xw, xw + sx*4])
    base = box(xa, xb, SIDE_Y - 7, SIDE_Y + 7, SIDE_Z - 18, SIDE_Z + 18).edges("|X").fillet(5)
    base = base.edges(">X" if sx > 0 else "<X").fillet(1.2)
    for ez in (-10.5, 7.5):
        ea, eb = sorted([xw + sx*3, xw + sx*15])
        ear = box(ea, eb, SIDE_Y - 6, SIDE_Y + 6, SIDE_Z + ez, SIDE_Z + ez + 3)
        ear = ear.edges("|Z").edges(">X" if sx > 0 else "<X").fillet(5.9)
        base = base.union(ear)
    base = base.cut(_zcyl(3.2, 40, xw + sx*9, SIDE_Y, SIDE_Z - 20))
    for z in SIDE_SCREWS_Z:
        x0 = min(xw - sx*1, xw + sx*6)
        base = base.cut(_xcyl(3.4, 8, x0, SIDE_Y, z))
        hx = xw + sx*4 - (sx*2.0 if sx > 0 else 0) - (0 if sx > 0 else 0)
        base = base.cut(_xcyl(6.2, 2.0, min(xw + sx*2.0, xw + sx*4.01), SIDE_Y, z))
    return base


def d_ring_side(sx):
    xw = sx*W/2
    wire = cq.Wire.assembleEdges([
        cq.Edge.makeLine(cq.Vector(0, -5.5, 0), cq.Vector(0, 5.5, 0)),
        cq.Edge.makeLine(cq.Vector(0, 5.5, 0), cq.Vector(12, 5.5, 0)),
        cq.Edge.makeThreePointArc(cq.Vector(12, 5.5, 0), cq.Vector(17.5, 0, 0), cq.Vector(12, -5.5, 0)),
        cq.Edge.makeLine(cq.Vector(12, -5.5, 0), cq.Vector(0, -5.5, 0)),
    ])
    prof = cq.Wire.makeCircle(1.75, cq.Vector(0, -5.5, 0), cq.Vector(0, 1, 0))
    ring = cq.Workplane("XY").add(cq.Solid.sweep(cq.Face.makeFromWires(prof), wire, transitionMode="round"))
    # ring lies in the X-Y plane; straight bar along Y must lie along the pin (Z) -> rotate about X
    ring = ring.rotate((0, 0, 0), (1, 0, 0), 90)
    if sx < 0:
        ring = ring.mirror("YZ")
    return ring.translate((xw + sx*(9 - 3.2), SIDE_Y, SIDE_Z))   # pin runs inside the ring


def bottom_anchor():
    y0 = -TOP
    base = box(-20, 20, y0 - 4, y0, BOT_Z - 18, BOT_Z + 18).edges("|Y").fillet(6).edges("<Y").fillet(1.2)
    for ex in (-10.5, 7.5):
        ear = box(ex, ex + 3, y0 - 15, y0 - 3, BOT_Z - 6, BOT_Z + 6).edges("|X").edges("<Y").fillet(5.9)
        base = base.union(ear)
    base = base.cut(_xcyl(3.2, 30, -15, y0 - 9, BOT_Z))
    for (x, z) in BOT_SCREWS:
        base = base.cut(_ycyl(3.4, 10, x, y0 - 6, z))
        base = base.cut(_ycyl(6.2, 2.0, x, y0 - 4.01, z))
    return base


def d_ring_bottom():
    wire = cq.Wire.assembleEdges([
        cq.Edge.makeLine(cq.Vector(-5.5, 0, 0), cq.Vector(5.5, 0, 0)),
        cq.Edge.makeLine(cq.Vector(5.5, 0, 0), cq.Vector(5.5, -12, 0)),
        cq.Edge.makeThreePointArc(cq.Vector(5.5, -12, 0), cq.Vector(0, -17.5, 0), cq.Vector(-5.5, -12, 0)),
        cq.Edge.makeLine(cq.Vector(-5.5, -12, 0), cq.Vector(-5.5, 0, 0)),
    ])
    prof = cq.Wire.makeCircle(1.75, cq.Vector(-5.5, 0, 0), cq.Vector(1, 0, 0))
    ring = cq.Workplane("XY").add(cq.Solid.sweep(cq.Face.makeFromWires(prof), wire, transitionMode="round"))
    return ring.translate((0, -TOP - 9 + 3.2, BOT_Z))   # pin runs inside the ring


def tpu_rest(sx):
    xa, xb = sorted([sx*REST_X0, sx*REST_X1])
    r = box(xa, xb, -TOP - 3, -TOP, REST_Z0, REST_Z1).edges("|Y").fillet(8).edges("<Y").fillet(1.4)
    zc = (REST_Z0 + REST_Z1)/2
    x = sx*65.0
    r = r.cut(_ycyl(3.4, 5, x, -TOP - 4, zc))
    r = r.cut(_ycyl(6.4, 1.6, x, -TOP - 3.2, zc))
    return r


def body_mods(b):
    # side anchors: printable pillars from the front panel, inserts along X
    for sx in (1, -1):
        xi = sx*(W/2 - T)
        xa, xb = sorted([xi + sx*0.5, xi - sx*7.5])
        b = b.union(box(xa, xb, SIDE_Y - 4.5, SIDE_Y + 4.5, SIDE_SCREWS_Z[0] - 4.5, D - T + 0.01))
        for z in SIDE_SCREWS_Z:
            b = b.cut(_xcyl(4.0, 8.5, min(sx*(W/2 + 0.5), sx*(W/2 - 8)), SIDE_Y, z))
    # bottom anchor: inserts into the bottom seam ribs
    for (x, z) in BOT_SCREWS:
        b = b.cut(_ycyl(4.0, 9, x, -TOP - 0.01, z))
    # TPU rest: pillars + inserts
    zc = (REST_Z0 + REST_Z1)/2
    for sx in (1, -1):
        x = sx*65.0
        b = b.union(box(x - 4, x + 4, -TOP + T - 0.5, -TOP + T + 7, zc - 4.5, D - T + 0.01))
        b = b.cut(_ycyl(4.0, 8, x, -TOP - 0.5, zc))
    return b
