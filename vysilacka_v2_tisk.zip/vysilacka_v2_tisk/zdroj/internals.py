# Lid with an internal mounting grid + cable-tie loops (closed coords, lid z -3..0, features grow into the box)
import cadquery as cq
from model import box, cyl, W, H, T, RIB_T, BOLT_Y
from rounded import rbox, boss_positions

GRID_X = [sx*(20 + 25*k) for sx in (1, -1) for k in range(6)]     # ±20 … ±145
GRID_Y = [-50, -25, 0, 25, 50]
BOSS_D, BOSS_H, BOSS_HOLE = 7.0, 6.0, 2.5                          # M3 self-tapping screws (or M3 insert after drilling to 4.0)
LOOPS = [(sx*x, sy*64.0) for sx in (1, -1) for x in (32.5, 82.5, 132.5) for sy in (1, -1)]


def grid_points(s):
    pts = []
    corners = boss_positions(s["R"])
    for x in GRID_X:
        for y in GRID_Y:
            if abs(x) < 14:   # lap joint area
                continue
            if any(abs(x - cx) < 10 and abs(y - cy) < 10 for cx, cy in corners):
                continue
            pts.append((x, y))
    return pts


def tie_loop(x, y):
    """Bridge loop: 6 wide (x), 12 long (y), 5 high, tunnel 3 x 2.2 for a 2.5 mm cable tie."""
    lp = box(x - 3, x + 3, y - 6, y + 6, -0.01, 5).edges("|X").edges(">Z").fillet(1.5)
    return lp.cut(box(x - 4, x + 4, y - 4.5, y + 4.5, -0.02, 2.2)).cut(box(x - 1.5, x + 1.5, y - 7, y + 7, -0.02, 2.2))


def lid_with_internals(s, lap=10.0, t=3.0):
    z0 = -t
    plate = rbox(W, H, z0, 0, s["R"], s["RB"], top=False)
    cham = box(-W/2, W/2, -H/2, H/2, z0, 1).edges("|Z").fillet(s["R"]).edges("<Z").chamfer(s["RB"]*(2 - 2**0.5))
    plate = plate.intersect(cham)          # lid prints outer face down
    for (x, y) in grid_points(s):
        plate = plate.union(cyl(BOSS_D, BOSS_H + 0.01, x, y, -0.01))
    for (x, y) in LOOPS:
        lp = box(x - 3, x + 3, y - 6, y + 6, -0.01, 5).edges("|Y").edges(">Z").fillet(2.4)
        lp = lp.cut(box(x - 4, x + 4, y - 4.5, y + 4.5, -0.05, 2.5))          # tunnel for the tie (runs along x)
        plate = plate.union(lp)
    for (x, y) in grid_points(s):
        plate = plate.cut(cyl(BOSS_HOLE, BOSS_H + 1.8, x, y, -1.8))   # blind, 1.2 mm skin
    for (x, y) in boss_positions(s["R"]):
        plate = plate.cut(cyl(3.4, t + 2, x, y, z0 - 1))
    for dx in (-RIB_T/2, RIB_T/2):
        for sy in (1, -1):
            plate = plate.cut(cyl(3.4, t + 2, dx, sy*BOLT_Y, z0 - 1))
    # butt joint at x=0 (each half screws into its own body half) - prints without supports
    L = plate.intersect(box(-W, 0, -H, H, z0 - 1, 20))
    R = plate.intersect(box(0, W, -H, H, z0 - 1, 20))
    return L, R
