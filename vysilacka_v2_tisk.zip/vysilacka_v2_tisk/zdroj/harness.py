# Harness: top centre eye (bridges the seam), two bottom D-ring anchors, TPU belly rest.
import math
import cadquery as cq
from model import box, cyl, H, T

TOP = H/2            # 80
EYE_SCREWS = [(sx*3.0, z) for sx in (1, -1) for z in (20.0, 34.0)]   # into the seam ribs (x ±0..6)
ANCH_X = 130.0
ANCH_Z = 25.0
ANCH_SCREWS = [(dx, dz) for dx in (-9.0, 9.0) for dz in (-9.0, 9.0)]
REST_X, REST_Z0, REST_Z1 = 105.0, 8.0, 44.0
REST_SCREWS = [-60.0, 60.0]


def top_eye():
    base = box(-20, 20, TOP, TOP + 4, 8, 44).edges("|Y").fillet(6).edges(">Y").fillet(1.2)
    eye = box(-6, 6, TOP + 3, TOP + 22, 16, 36).edges("|X").edges(">Y").fillet(9.5)
    e = base.union(eye)
    e = e.cut(cyl(10, 20, -10, TOP + 13, 26, axis="x"))
    for (x, z) in EYE_SCREWS:
        e = e.cut(cyl(3.4, 10, x, TOP - 1, z, axis="y").translate((0, 0, 0)))
    return e


def _ycyl(d, h, x, y0, z):
    """cylinder along +Y starting at y0"""
    return cq.Workplane("XZ").circle(d/2).extrude(-h).translate((x, y0, z))


def top_eye_fixed():
    e = top_eye()
    for (x, z) in EYE_SCREWS:
        e = e.cut(_ycyl(3.4, 10, x, TOP - 1, z))
        e = e.cut(_ycyl(6.2, 3.0, x, TOP + 4 - 2.0, z))    # counterbore for the head
    return e


def body_mods(b):
    """Insert holes for the eye (into seam ribs) and bosses + insert holes for anchors and rest."""
    for (x, z) in EYE_SCREWS:
        b = b.cut(_ycyl(4.0, 9, x, TOP - 9, z))
    # pillars from the front panel down to the screw points (print face-down without supports)
    PZTOP = 52.01
    for sx in (1, -1):
        for dx in (-9.0, 9.0):
            x = sx*ANCH_X + dx
            b = b.union(box(x - 4, x + 4, -TOP + T - 0.5, -TOP + T + 7, ANCH_Z - 9 - 4.5, PZTOP))
            for dz in (-9.0, 9.0):
                b = b.cut(_ycyl(4.0, 8, x, -TOP - 0.5, ANCH_Z + dz))
    zc = (REST_Z0 + REST_Z1)/2
    for x in REST_SCREWS:
        b = b.union(box(x - 4, x + 4, -TOP + T - 0.5, -TOP + T + 7, zc - 4.5, PZTOP))
        b = b.cut(_ycyl(4.0, 8, x, -TOP - 0.5, zc))
    return b


def anchor(sx):
    x0 = sx*ANCH_X
    base = box(x0 - 15, x0 + 15, -TOP - 4, -TOP, ANCH_Z - 15, ANCH_Z + 15).edges("|Y").fillet(5).edges("<Y").fillet(1.2)
    for ex in (-10.5, 7.5):
        ear = box(x0 + ex, x0 + ex + 3, -TOP - 14, -TOP - 3, ANCH_Z - 6, ANCH_Z + 6).edges("|X").edges("<Y").fillet(5.9)
        base = base.union(ear)
    base = base.cut(cyl(3.2, 30, x0 - 15, -TOP - 9, ANCH_Z, axis="x"))
    for (dx, dz) in ANCH_SCREWS:
        base = base.cut(_ycyl(3.4, 10, x0 + dx, -TOP - 6, ANCH_Z + dz))
        base = base.cut(_ycyl(6.2, 3, x0 + dx, -TOP - 4.5, ANCH_Z + dz))
    return base


def d_ring(sx):
    """20 mm steel D-ring hanging from the anchor pin (pin axis along X at y=-89, z=25)."""
    x0 = sx*ANCH_X
    # simple robust model: torus-like D from swept circle along a closed wire
    wire = cq.Wire.assembleEdges([
        cq.Edge.makeLine(cq.Vector(-7, 0, 0), cq.Vector(7, 0, 0)),
        cq.Edge.makeThreePointArc(cq.Vector(7, 0, 0), cq.Vector(0, -19, 0), cq.Vector(-7, 0, 0)),
    ])
    prof = cq.Wire.makeCircle(1.75, cq.Vector(-7, 0, 0), cq.Vector(1, 0, 0))
    solid = cq.Solid.sweep(cq.Face.makeFromWires(prof), wire, transitionMode="round")
    return cq.Workplane("XY").add(solid).translate((x0, -TOP - 9, ANCH_Z))


def tpu_rest():
    r = box(-REST_X, REST_X, -TOP - 3, -TOP, REST_Z0, REST_Z1).edges("|Y").fillet(8).edges("<Y").fillet(1.4)
    for x in REST_SCREWS:
        zc = (REST_Z0 + REST_Z1)/2
        r = r.cut(_ycyl(3.4, 5, x, -TOP - 4, zc))
        r = r.cut(_ycyl(6.4, 1.6, x, -TOP - 3.2, zc))
    return r
