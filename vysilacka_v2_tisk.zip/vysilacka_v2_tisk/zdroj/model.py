# Parametric rebuild of vysilacka_v1 + split variants (CadQuery)
import cadquery as cq

# ---- original parameters (from FCMacro) ----
W, H, D, T = 330.0, 160.0, 55.0, 3.0
DISP_W, DISP_H, DISP_Y = 156.0, 87.0, 5.0
POST_X, POST_DY, POST_D, POST_H = 102.0, 60.0, 8.0, 7.0
GIMB_X, GIMB_S, GIMB_SCR = 130.0, 46.0, 27.0
SW_X, SW_Y, SW_D = 70.0, 68.0, 6.4
ROCK_X, ROCK_W, ROCK_H = 135.0, 19.4, 13.2
ANT_X, ANT_D = 110.0, 6.5
BOSS = (158.5, 73.5)
EAR_X, EAR_Y0, EAR_Y1 = 90.0, 50.5, 58.5

# ---- joint parameters ----
RIB_T = 6.0        # rib thickness per side of seam
RIB_Y0, RIB_Y1 = 69.0, 77.0
BOLT_Y = 73.0
BOLT_Z = (14.0, 40.0)
INSERT_D = 4.0     # hole for M3 heat-set insert (OD 4.6-5)
CLEAR_D = 3.4
HEAD_D = 6.0


def box(x0, x1, y0, y1, z0, z1):
    return cq.Workplane("XY").box(x1 - x0, y1 - y0, z1 - z0, centered=False).translate((x0, y0, z0))


def cyl(d, h, x, y, z, axis="z"):
    w = cq.Workplane("XY").circle(d / 2).extrude(h)
    if axis == "x":
        w = cq.Workplane("YZ").circle(d / 2).extrude(h)
    elif axis == "y":
        w = cq.Workplane("XZ").circle(d / 2).extrude(-h)
    return w.translate((x, y, z))


def body(with_ears=True):
    b = box(-W/2, W/2, -H/2, H/2, 0, D).cut(box(-W/2+T, W/2-T, -H/2+T, H/2-T, -1, D-T))
    for sx in (1, -1):
        for sy in (1, -1):
            b = b.union(cyl(POST_D, POST_H + 1, sx*POST_X, DISP_Y + sy*POST_DY, D - T - POST_H))
            b = b.union(cyl(9, 10, sx*BOSS[0], sy*BOSS[1], 0))
        if with_ears:
            b = b.union(box(sx*EAR_X - 2, sx*EAR_X + 2, EAR_Y0, EAR_Y1, D - 1, D + 10))
    cuts = [box(-DISP_W/2, DISP_W/2, DISP_Y - DISP_H/2, DISP_Y + DISP_H/2, D - T - 1, D + 1)]
    for sx in (1, -1):
        for sy in (1, -1):
            cuts.append(cyl(2.6, POST_H + 1, sx*POST_X, DISP_Y + sy*POST_DY, D - T - POST_H - 0.5))
            cuts.append(cyl(2.6, 11, sx*BOSS[0], sy*BOSS[1], -0.5))
            cuts.append(cyl(3.4, T + 2, sx*GIMB_X + 27, sy*27, D - T - 1))
            cuts.append(cyl(3.4, T + 2, sx*GIMB_X - 27, sy*27, D - T - 1))
        cuts.append(box(sx*GIMB_X - GIMB_S/2, sx*GIMB_X + GIMB_S/2, -GIMB_S/2, GIMB_S/2, D - T - 1, D + 1))
        cuts.append(cyl(SW_D, T + 2, sx*SW_X, SW_Y, D - T - 1))
        cuts.append(box(sx*ROCK_X - ROCK_W/2, sx*ROCK_X + ROCK_W/2, H/2 - T - 1, H/2 + 1, D/2 - ROCK_H/2, D/2 + ROCK_H/2))
        cuts.append(cyl(ANT_D, T + 2, sx*ANT_X, H/2 - T - 1, D/2, axis="y").translate((0, 0, 0)))
    cuts.append(box(W/2 - T - 1, W/2 + 1, 15, 45, D/2 - 2.25, D/2 + 2.25))
    if with_ears:
        cuts.append(cyl(3.4, 200, -100, (EAR_Y0 + EAR_Y1)/2, D + 5, axis="x"))
    for c in cuts:
        b = b.cut(c)
    return b


def ant_fix():
    pass


def seam_ribs(xs, side, front_top=(60.0, 69.0), front_bot=(-62.0, -69.0)):
    """Ribs at seam plane x=xs. side=-1 -> rib on left (x<xs) with clearance+counterbore,
    side=+1 -> rib on right with insert holes."""
    x0, x1 = (xs - RIB_T, xs) if side < 0 else (xs, xs + RIB_T)
    solid = None
    for sy in (1, -1):
        r = box(x0, x1, min(sy*RIB_Y0, sy*RIB_Y1), max(sy*RIB_Y0, sy*RIB_Y1), 0, D - T + 0.01)
        ft = front_top if sy > 0 else front_bot
        if ft:
            r = r.union(box(x0, x1, min(sy*abs(ft[0]), sy*abs(ft[1])), max(sy*abs(ft[0]), sy*abs(ft[1])), D - T - 6, D - T + 0.01))   # front rib extension (6 mm, clears the display clamp strip)
        solid = r if solid is None else solid.union(r)
    holes = []
    for sy in (1, -1):
        for z in BOLT_Z:
            if side < 0:
                holes.append(cyl(CLEAR_D, RIB_T + 2, x0 - 1, sy*BOLT_Y, z, axis="x"))
                holes.append(cyl(HEAD_D, 2.5, x0 - 0.01, sy*BOLT_Y, z, axis="x"))
            else:
                holes.append(cyl(INSERT_D, 5.5, xs - 0.01, sy*BOLT_Y, z, axis="x"))
        # vertical insert for the lid lap screw
        holes.append(cyl(INSERT_D, 7, (x0 + x1)/2, sy*BOLT_Y, -0.01))
    return solid, holes


def split_body(b, seams, rib_cfg=None):
    """Split body at x positions; return list of pieces with joints."""
    edges = [-W/2 - 1] + list(seams) + [W/2 + 1]
    pieces = []
    for i in range(len(edges) - 1):
        p = b.intersect(box(edges[i], edges[i+1], -H/2 - 1, H/2 + 1, -1, D + 20))
        hole_list = []
        for j, xs in enumerate(seams):
            cfg = (rib_cfg or {}).get(j, {})
            if abs(xs - edges[i+1]) < 1e-6:   # seam on our right -> left-side rib
                s, hl = seam_ribs(xs, -1, **cfg)
            elif abs(xs - edges[i]) < 1e-6:   # seam on our left -> right-side rib
                s, hl = seam_ribs(xs, +1, **cfg)
            else:
                continue
            p = p.union(s)
            hole_list += hl
        for h in hole_list:
            p = p.cut(h)
        pieces.append(p)
    return pieces


def lid_pieces(seams, z0=-3.0, lap=10.0, t=3.0):
    LW, LH = W - 2*T - 0.4, H - 2*T - 0.4
    edges = [-LW/2] + list(seams) + [LW/2]
    out = []
    for i in range(len(edges) - 1):
        a, b_ = edges[i], edges[i+1]
        # lower half extends left over neighbour on left seam, upper half extends right on right seam
        p = box(a + (lap if i > 0 else 0), b_ - (lap if i < len(edges)-2 else 0), -LH/2, LH/2, z0, z0 + t)
        if i > 0:
            p = p.union(box(a - lap, a + lap, -LH/2, LH/2, z0, z0 + t/2))
        if i < len(edges) - 2:
            p = p.union(box(b_ - lap, b_ + lap, -LH/2, LH/2, z0 + t/2, z0 + t))
        for sx in (1, -1):
            for sy in (1, -1):
                p = p.cut(cyl(3.4, t + 2, sx*BOSS[0], sy*BOSS[1], z0 - 1))
        for xs in seams:
            for dx in (-RIB_T/2, RIB_T/2):
                for sy in (1, -1):
                    p = p.cut(cyl(3.4, t + 2, xs + dx, sy*BOLT_Y, z0 - 1))
        out.append(p)
    return out


def bezel():
    """Variant C: front display bezel carrying the hinge ears, hides the centre seam."""
    X, Y0, Y1, t = 100.0, -62.0, 75.0, 3.0
    z0 = D
    bz = box(-X, X, Y0, Y1, z0, z0 + t).edges("|Z").fillet(6)
    for sx in (1, -1):
        bz = bz.union(box(sx*EAR_X - 2, sx*EAR_X + 2, EAR_Y0, EAR_Y1, z0 + t - 0.5, z0 + t + 10))
    bz = bz.cut(box(-DISP_W/2, DISP_W/2, DISP_Y - DISP_H/2, DISP_Y + DISP_H/2, z0 - 1, z0 + t + 1))
    bz = bz.cut(cyl(3.4, 200, -100, (EAR_Y0 + EAR_Y1)/2, z0 + t + 5, axis="x"))
    for sx in (1, -1):
        bz = bz.cut(cyl(SW_D, t + 2, sx*SW_X, SW_Y, z0 - 1))
        for x in (40, 95):
            for y in (66, -56):
                bz = bz.cut(cyl(INSERT_D, 2.5, sx*x, y, z0 - 0.01))
    return bz


def bezel_holes_in_body(b):
    for sx in (1, -1):
        for x in (40, 95):
            for y in (66, -56):
                b = b.cut(cyl(3.4, T + 2, sx*x, y, D - T - 1))
    return b


def clona():
    CW, CD, CB = 210.0, 70.0, 55.0
    c = box(0, CW, -CD/2, CD/2, 0, T)
    c = c.union(box(0, T, -CD/2, CD/2, 0, CB)).union(box(CW - T, CW, -CD/2, CD/2, 0, CB))
    for s in (1, -1):
        xc = CW/2 + s*(90 - 4 - 0.4)
        c = c.union(box(xc - 2, xc + 2, CD/2 - 8, CD/2, 0, 13))
    c = c.cut(cyl(3.4, 200, CW/2 - 100, CD/2 - 4, 8, axis="x"))
    return c.translate((-CW/2, 0, 0))


def lista():
    L = 216.0
    l = box(-L/2, L/2, -4, 4, 0, 3)
    for x in (-102, 102):
        l = l.cut(cyl(3.4, 5, x, 0, -1))
    return l
