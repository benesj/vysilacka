import json, os, cadquery as cq, trimesh, numpy as np
from rounded import STYLES, body, halves
from shade2 import *
from internals import lid_with_internals
from harness import *
from model import lista
s=dict(STYLES['S2'],key='S2')
OUT='/home/claude/viewer5'; os.makedirs(OUT+'/stl',exist_ok=True)
b=body_mods(body(s)); L,R=halves(b); lL,lR=lid_with_internals(s)
parts={'telo_L':L,'telo_P':R,'ramecek':bezel2(s),'viko_L':lL,'viko_P':lR,'deska':plate2(s),
 'dvirka_L':door(-1,s),'dvirka_P':door(1,s),'sou_L':pin(-1),'sou_P':pin(1),
 'lista_1':lista().translate((0,-48,38)),'lista_2':lista().translate((0,58,38)),
 'oko':top_eye_fixed(),'uchyt_L':anchor(-1),'uchyt_P':anchor(1),'krouzek_L':d_ring(-1),'krouzek_P':d_ring(1),'opera':tpu_rest()}
info={}
for k,o in parts.items():
    v=o.val(); bb=v.BoundingBox()
    info[k]=(v.isValid(),len(o.solids().vals()),[int(round(x)) for x in (bb.xlen,bb.ylen,bb.zlen)])
    cq.exporters.export(o,f'{OUT}/stl/{k}.stl',tolerance=0.05,angularTolerance=0.12)
for k in ('telo_L','telo_P','oko','uchyt_L','krouzek_L','opera'): print(k,info[k])
def V(a,c):
    try: return round(a.intersect(c).val().Volume(),1)
    except Exception: return 0.0
body_all=L.union(R)
print('eye∩body',V(parts['oko'],body_all),'anch∩body',V(parts['uchyt_P'],body_all),'rest∩body',V(parts['opera'],body_all),
      'rest∩anch',V(parts['opera'],parts['uchyt_P']),'eye∩bezel',V(parts['oko'],parts['ramecek']))
# eye vs plate in closed/open states, anchors vs doors open
H_=((0,HY,HZ),(1,HY,HZ))
print('eye∩plate closed',V(parts['oko'],parts['deska']),'open',V(parts['oko'],parts['deska'].rotate(*H_,-90)),'-130',V(parts['oko'],parts['deska'].rotate(*H_,-130)))
recs=[]
for k in parts:
    m=trimesh.load(f'{OUT}/stl/{k}.stl'); m.merge_vertices()
    recs.append({"file":k,"v":np.round(m.vertices,2).ravel().tolist(),"i":m.faces.ravel().tolist()})
open(f'{OUT}/meshes.json','w').write('[\n'+',\n'.join(json.dumps(r,separators=(',',':')) for r in recs)+'\n]')
print(os.path.getsize(f'{OUT}/meshes.json')/1e6,'MB')
