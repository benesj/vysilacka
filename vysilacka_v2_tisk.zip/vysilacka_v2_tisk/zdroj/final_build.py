import json, os, sys, cadquery as cq
from rounded import STYLES, body, halves
from shade2 import *
from internals import lid_with_internals
import harness3 as hz
from model import lista, box as _box, cyl as _cyl
# display clamp strips: 216 x 18 x 3, hole 4 mm from the outer edge, inner edge overlaps the display edge by ~9 mm
def _strip():
    s=_box(-108,108,-4,14,0,3).edges("|Z").fillet(2)
    for x in (-102,102): s=s.cut(_cyl(3.4,5,x,0,-1))
    return s
def lista_top():    # posts at y=65 -> strip reaches down to y=51 (display top edge at 60)
    return _strip().mirror("XZ").translate((0,65,42))
def lista_bottom(): # posts at y=-55 -> strip reaches up to y=-41 (display bottom edge at -50)
    return _strip().translate((0,-55,42))
s=dict(STYLES['S2'],key='S2')
b=hz.body_mods(body(s)); L,R=halves(b); lL,lR=lid_with_internals(s)
P=dict(telo_L=L,telo_P=R,viko_L=lL,viko_P=lR,ramecek=bezel2(s),deska=plate2(s),dvirka_L=door(-1,s),dvirka_P=door(1,s),
       knof_L=pin(-1),knof_P=pin(1),kolik_L=dowel(-1),kolik_P=dowel(1),
       lista_1=lista_top(),lista_2=lista_bottom(),
       uchyt_HL=hz.side_anchor(-1),uchyt_HP=hz.side_anchor(1),uchyt_H=hz.front_anchor(),
       cep_HL=hz.side_pin(-1),cep_HP=hz.side_pin(1),cep_H=hz.front_pin(),
       opera=hz.tpu_rest())
for (x,y) in hz.F_BOLTS:
    P['ramecek']=P['ramecek'].cut(hz._zcyl(3.4, 5, x, y, 54.0))
ok=True
for k,o in P.items():
    v=o.val(); n=len(o.solids().vals())
    if not v.isValid() or n!=1: print('BAD',k,v.isValid(),n); ok=False
def V(a,c):
    try: return round(a.intersect(c).val().Volume(),2)
    except Exception: return 0.0
bodyU=L.union(R)
stat={k:V(P[k],bodyU) for k in ('ramecek','viko_L','viko_P','uchyt_HL','uchyt_HP','uchyt_H','opera')}
stat['front_anchor_bezel']=V(P['uchyt_H'],P['ramecek'])
for k in ('cep_HL','cep_HP'): stat[k]=V(P[k],P['uchyt_'+k[4:]].union(bodyU))
stat['cep_H']=V(P['cep_H'],P['uchyt_H'].union(P['ramecek']))
print('static',{k:v for k,v in stat.items() if v>0} or 'OK')
fixed=bodyU
for k in ('ramecek','viko_L','viko_P','uchyt_HL','uchyt_HP','uchyt_H','opera','cep_HL','cep_HP','cep_H'): fixed=fixed.union(P[k])
H_=((0,HY,HZ),(1,HY,HZ)); dL,dR=P['dvirka_L'],P['dvirka_P']
def doors(a): return dL.rotate((-DAX,0,DAZ),(-DAX,1,DAZ),-a), dR.rotate((DAX,0,DAZ),(DAX,1,DAZ),a)
def shade(a,t):
    asm=[P['deska'],P['knof_L'].translate((-t,0,0)),P['knof_P'].translate((t,0,0)),P['kolik_L'].translate((-t,0,0)),P['kolik_P'].translate((t,0,0))]
    return [x.rotate(*H_,a) for x in asm]
for tag,pa,da,t in [('closed',0,0,0),('up',-130,0,0),('d45',-130,45,0),('d90',-130,90,0),('down110',-110,90,0),('down100',-100,90,0),('final',-90,90,0),('locked',-90,90,PIN_TRAVEL)]:
    sh=shade(pa,t); Ld,Rd=doors(da)
    r={'P_fix':V(sh[0],fixed),'L_fix':V(Ld,fixed),'R_fix':V(Rd,fixed),'P_R':V(sh[0],Rd),'P_L':V(sh[0],Ld),
       'knob_R':V(sh[2],Rd),'dowel_R':V(sh[4],Rd),'dowel_P':V(sh[4],sh[0]),'knob_P':V(sh[2],sh[0]),'dowelL_L':V(sh[3],Ld)}
    nz={k:v for k,v in r.items() if v>0}; print(tag, nz or 'OK'); ok&= not nz
sh=shade(-90,PIN_TRAVEL); bb=sh[4].val().BoundingBox(); print('dowel locked x',round(bb.xmin,1),round(bb.xmax,1),'door plane',DOOR_PLANE-1.5,DOOR_PLANE+1.5)
sh=shade(-90,0); bb=sh[4].val().BoundingBox(); print('dowel retracted x max',round(bb.xmax,1))
print('ALL CLEAR' if ok else 'PROBLEMS')
import pickle
cq.exporters.export  # keep
os.makedirs('/home/claude/out_parts',exist_ok=True)
for k,o in P.items(): cq.exporters.export(o,f'/home/claude/out_parts/{k}.step')

# ---------------- exports ----------------
import trimesh, numpy as np, shutil
VDIR='/home/claude/viewer6'; os.makedirs(VDIR+'/stl',exist_ok=True)
recs=[]
for k,o in P.items():
    f=f'{VDIR}/stl/{k}.stl'; cq.exporters.export(o,f,tolerance=0.05,angularTolerance=0.12)
    m=trimesh.load(f); m.merge_vertices()
    recs.append({"file":k,"v":np.round(m.vertices,2).ravel().tolist(),"i":m.faces.ravel().tolist()})
open(f'{VDIR}/meshes.json','w').write('[\n'+',\n'.join(json.dumps(r,separators=(',',':')) for r in recs)+'\n]')

PRINT=[('01_telo_leva','telo_L','ASA','x180'),('02_telo_prava','telo_P','ASA','x180'),('03_ramecek_displeje','ramecek','ASA','none'),
 ('04_viko_leve','viko_L','ASA','none'),('05_viko_prave','viko_P','ASA','none'),('06_stinitko_deska','deska','ASA','none'),
 ('07_lista_displeje_A','lista_1','ASA','none'),('08_lista_displeje_B','lista_2','ASA','none'),
 ('09_dvirka_leva','dvirka_L','ASA','none'),('10_dvirka_prava','dvirka_P','ASA','none'),
 ('11_knoflik_soupatka_L','knof_L','ASA','x180'),('12_knoflik_soupatka_P','knof_P','ASA','x180'),
 ('13_uchyt_bocni_levy','uchyt_HL','ASA','none'),('14_uchyt_bocni_pravy','uchyt_HP','ASA','none'),
 ('15_uchyt_hlavni_pod_displejem','uchyt_H','ASA','none'),('16_operka','opera','TPU','x-90')]
PD='/home/claude/vysilacka_v2_tisk'
for sub in ('STL','STEP'):
    shutil.rmtree(f'{PD}/{sub}',ignore_errors=True); os.makedirs(f'{PD}/{sub}',exist_ok=True)   # keep NAVOD.md, 3MF, zdroj
rows=[]
for name,k,mat,rot in PRINT:
    o=P[k]
    if rot=='x180': o=o.rotate((0,0,0),(1,0,0),180)
    elif rot=='x-90': o=o.rotate((0,0,0),(1,0,0),-90)
    elif rot=='y90': o=o.rotate((0,0,0),(0,1,0),90)
    elif rot=='y-90': o=o.rotate((0,0,0),(0,1,0),-90)
    bb=o.val().BoundingBox(); o=o.translate((-(bb.xmin+bb.xmax)/2,-(bb.ymin+bb.ymax)/2,-bb.zmin)); bb=o.val().BoundingBox()
    fn=f'{name}_{mat}'
    cq.exporters.export(o,f'{PD}/STL/{fn}.stl',tolerance=0.02,angularTolerance=0.08)
    cq.exporters.export(o,f'{PD}/STEP/{fn}.step')
    d=[bb.xlen,bb.ylen,bb.zlen]; fits=(max(d[0],d[1])<=250 and min(d[0],d[1])<=210 and d[2]<=220)
    m=trimesh.load(f'{PD}/STL/{fn}.stl')
    rows.append((fn,mat,[round(x,1) for x in d],fits,m.is_watertight,round(o.val().Volume()/1000,1)))
# assembly STEP for FreeCAD
asm=cq.Assembly()
for k,o in P.items(): asm.add(o,name=k)
asm.save(f'{PD}/STEP/00_sestava_vysilacka_v2.step')
for r in rows: print(r)
json.dump(rows,open('/home/claude/print_rows.json','w'),ensure_ascii=False)
