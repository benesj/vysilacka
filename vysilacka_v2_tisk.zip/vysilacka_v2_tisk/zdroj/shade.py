# Flip-out display shade, modelled in CLOSED position (lying over the bezel)
import cadquery as cq
from model import box, cyl
from rounded import STYLES

HINGE_Y, HINGE_Z = 54.5, 63.0      # main hinge axis (along X) = bezel ears
PX, PY0, PY1 = 98.0, -60.0, 49.0   # plate extent (closed)
PZ0, PT = 59.0, 3.0                # plate underside 1 mm above bezel (bezel top = 58)
ARM_X = 83.6                       # knuckle arm centre (inside bezel ears at 88..92)
FLAP_AX = PX + 2.0                 # flap hinge axis x, outside plate edge so the open flap clears it
FLAP_AZ = PZ0 + PT + 1.5           # flap hinge axis z
FLAP_D_NEAR, FLAP_D_FAR = 55.0, 25.0
MAG_D, MAG_H = 6.2, 3.2            # 6x3 mm neodymium magnet pockets
MAG_PTS = [(sx*86, -52) for sx in (1, -1)]


def plate(s, with_flap_knuckles):
    p = box(-PX, PX, PY0, PY1, PZ0, PZ0 + PT).edges("|Z").fillet(s["RZ"]).edges(">Z").fillet(1.2)
    for sx in (1, -1):
        arm = box(sx*ARM_X - 2, sx*ARM_X + 2, PY1 - 6, HINGE_Y + 4, PZ0, HINGE_Z + 4)
        arm = arm.edges("|X").edges(">Y").fillet(3.9)
        p = p.union(arm)
    p = p.cut(cyl(3.4, 200, -100, HINGE_Y, HINGE_Z, axis="x"))
    # magnet pockets on the underside (closed-position latch)
    for (x, y) in MAG_PTS:
        p = p.cut(cyl(MAG_D, MAG_H, x, y, PZ0 - 0.01))
    if with_flap_knuckles:
        for sx in (1, -1):
            for (y0, y1) in ((-58, -30), (-8, 14), (36, 47)):
                k = cyl(7, y1 - y0, sx*FLAP_AX, y0, FLAP_AZ, axis="y")
                k = k.union(box(min(sx*(PX - 4), sx*PX), max(sx*(PX - 4), sx*PX), y0, y1, PZ0, PZ0 + PT))
                p = p.union(k)
            p = p.cut(cyl(2.1, 120, sx*FLAP_AX, -60, FLAP_AZ, axis="y"))
            for (y0, y1) in ((-30, -8), (14, 36)):   # relief for the flap's knuckles
                p = p.cut(cyl(8.6, y1 - y0, sx*FLAP_AX, y0, FLAP_AZ, axis="y"))
    return p


def flap(sx):
    """Side flap in folded (closed) state: lies on top of the plate, extends inward from the hinge."""
    zb, zt = FLAP_AZ - 1.5, FLAP_AZ + 1.5
    # trapezoid in plan: deep near main hinge (y high), shallow at the tip (y low)
    pts = [(0, PY1 - 8), (FLAP_D_NEAR, PY1 - 8), (FLAP_D_FAR, PY0 + 4), (0, PY0 + 4)]
    f = cq.Workplane("XY").polyline(pts).close().extrude(zt - zb).translate((0, 0, zb))
    f = f.edges("|Z").fillet(6)
    if sx > 0:
        f = f.mirror("YZ")
    f = f.translate((sx*(FLAP_AX - 4.5), 0, 0))
    for (y0, y1) in ((-29.5, -8.5), (14.5, 35.5)):
        k = cyl(7, y1 - y0, sx*FLAP_AX, y0, FLAP_AZ, axis="y")
        web = box(min(sx*(FLAP_AX - 5), sx*FLAP_AX), max(sx*(FLAP_AX - 5), sx*FLAP_AX), y0, y1, zb, zt)
        f = f.union(k).union(web)
    # clearance around the plate's knuckles
    for (y0, y1) in ((-59, -29.5), (-8.5, 14.5), (35.5, 48)):
        f = f.cut(cyl(9.0, y1 - y0, sx*FLAP_AX, y0, FLAP_AZ, axis="y"))
    f = f.cut(cyl(2.1, 120, sx*FLAP_AX, -60, FLAP_AZ, axis="y"))
    return f
