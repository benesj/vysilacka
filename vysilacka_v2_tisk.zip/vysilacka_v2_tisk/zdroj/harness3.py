# Harness v3: lanyard (snap-hook) anchors. Solid blocks with a window; the hook clips around a steel M3 bolt
# used as a pin. Neck lanyard -> bottom-centre anchor; armpit lanyards -> two upper side anchors.
import cadquery as cq
from model import box, cyl, W, H, T, D

TOP = H/2
# ---- side anchors (right one described, left mirrored) ----
# Open cage on the side wall. The steel pin is an M3x20 bolt running OUT OF THE WALL (along X),
# screwed into an insert in an inner pillar. The strap pulls up and toward the user (Y-Z plane),
# i.e. perpendicular to the pin, and the cage is open at the top and at the front, so the snap hook
# can swing freely and never bends over an edge.
S_Y0, S_Y1 = 46.0, 60.0            # above the slider slot (y<=45), inside the flat wall (y<=60)
S_Z0, S_Z1 = 6.0, 46.0
S_PROT = 16.0                      # protrusion from the wall
S_BASE = 2.0                       # plate against the wall
S_EAR = 4.0                        # outer ear that carries the pin end
S_FLOOR = 4.0                      # bottom wall thickness (y)
S_REAR = 10.0                      # rear wall thickness (z)
S_PIN = (55.5, 27.0)               # pin position (y, z)
S_SCREWS = [(49.0, 11.0), (57.0, 11.0)]   # two more M3x20 through the rear wall
# ---- main front anchor (below the display): open clevis facing the user ----
# Two ears stand off the bezel, the steel pin (M3x25 + nylock) runs across them along X.
# The neck strap pulls toward the user (+Z) / along the body (Y-Z plane): perpendicular to the pin,
# and the clevis is open toward the user. Base through-bolted into both body halves (not the seam).
F_X = 18.0
F_Y0, F_Y1 = -70.0, -51.0
F_Z0 = 58.0                        # bezel top surface
F_BASE = 4.0
F_EAR_X = (6.0, 10.0)              # ears at |x| = 6..10 -> 12 mm gap for the hook
F_EAR_Y = (-67.0, -54.0)
F_PROT = 14.0
F_PIN = (-60.5, F_Z0 + 10.0)       # pin along X: (y, z) -> 4.5 mm under the pin for the hook
F_BOLTS = [(sx*14.0, y) for sx in (1, -1) for y in (-66.0, -55.0)]   # M3x16 through base+bezel+panel, nut inside
# ---- TPU belly rest ----
REST_Z0, REST_Z1 = 8.0, 44.0
REST_X0, REST_X1 = 0.0, 105.0     # one piece across


def _ycyl(d, h, x, y0, z):
    return cq.Workplane("XZ").circle(d/2).extrude(-h).translate((x, y0, z))


def _xcyl(d, h, x0, y, z):
    return cq.Workplane("YZ").circle(d/2).extrude(h).translate((x0, y, z))


def _zcyl(d, h, x, y, z0):
    return cq.Workplane("XY").circle(d/2).extrude(h).translate((x, y, z0))


def side_anchor(sx):
    xw = W/2
    x_in, x_out = xw, xw + S_PROT
    blk = box(x_in, x_out, S_Y0, S_Y1, S_Z0, S_Z1)
    # cavity: open at the top (+Y) and at the front (+Z)
    cav = box(x_in + S_BASE, x_out - S_EAR, S_Y0 + S_FLOOR, S_Y1 + 1, S_Z0 + S_REAR, S_Z1 + 1)
    blk = blk.cut(cav)
    # trim the outer ear to a rounded lug around the pin
    blk = blk.cut(box(x_out - S_EAR - 0.01, x_out + 1, S_Y0 + S_FLOOR, S_Y1 + 1, S_PIN[1] + 9, S_Z1 + 1))
    blk = blk.edges("|X").fillet(1.5)
    pin_hole = _xcyl(3.4, S_PROT + 2, x_in - 1, S_PIN[0], S_PIN[1])
    blk = blk.cut(pin_hole).cut(_xcyl(6.4, 3.0, x_out - 3.0, S_PIN[0], S_PIN[1]))
    for (y, z) in S_SCREWS:
        blk = blk.cut(_xcyl(3.4, S_PROT + 2, x_in - 1, y, z)).cut(_xcyl(6.4, 3.0, x_out - 3.0, y, z))
    return blk if sx > 0 else blk.mirror("YZ")


def side_pin(sx):
    xw = W/2
    p = _xcyl(3.0, 20, xw + S_PROT - 3.0 - 20 + 3.0 + 0.0, S_PIN[0], S_PIN[1]).translate((0, 0, 0))
    p = _xcyl(3.0, 19, xw - 6.0, S_PIN[0], S_PIN[1])          # M3x20 shank: from the insert to the head seat
    return p if sx > 0 else p.mirror("YZ")


def front_anchor():
    base = box(-F_X, F_X, F_Y0, F_Y1, F_Z0, F_Z0 + F_BASE).edges("|Z").fillet(5).faces(">Z").edges().fillet(1.2)
    for sx in (1, -1):
        xa, xb = sorted([sx*F_EAR_X[0], sx*F_EAR_X[1]])
        ear = box(xa, xb, F_EAR_Y[0], F_EAR_Y[1], F_Z0 + F_BASE - 0.5, F_Z0 + F_PROT)
        ear = ear.edges("|X").edges(">Z").fillet(6.4)
        base = base.union(ear)
    base = base.cut(_xcyl(3.4, 2*F_X + 2, -F_X - 1, F_PIN[0], F_PIN[1]))
    for (x, y) in F_BOLTS:
        base = base.cut(_zcyl(3.4, F_BASE + 2, x, y, F_Z0 - 1))
    return base


def front_pin():
    return _xcyl(3.0, 2*F_EAR_X[1] + 4, -F_EAR_X[1] - 1, F_PIN[0], F_PIN[1])


def tpu_rest():
    r = box(-REST_X1, REST_X1, -TOP - 3, -TOP, REST_Z0, REST_Z1).edges("|Y").fillet(8).edges("<Y").fillet(1.4)
    zc = (REST_Z0 + REST_Z1)/2
    for x in (-65.0, 65.0):
        r = r.cut(_ycyl(3.4, 5, x, -TOP - 4, zc))
        r = r.cut(_ycyl(6.4, 1.6, x, -TOP - 3.2, zc))
    return r


def body_mods(b):
    ins = [S_PIN] + S_SCREWS
    ys = [p[0] for p in ins]; zs = [p[1] for p in ins]
    for sx in (1, -1):
        xi = sx*(W/2 - T)
        xa, xb = sorted([xi + sx*0.5, xi - sx*7.5])
        b = b.union(box(xa, xb, max(min(ys) - 4.5, 45.5), max(ys) + 4.5, min(zs) - 4.5, D - T + 0.01))   # pillar from the front panel (clear of the slider slot y<=45)
        for (y, z) in ins:
            b = b.cut(_xcyl(4.0, 8.5, min(sx*(W/2 + 0.5), sx*(W/2 - 8)), y, z))
    for (x, y) in F_BOLTS:          # through-holes in the front panel for the main anchor bolts
        b = b.cut(_zcyl(3.4, T + 2, x, y, D - T - 1))
    zc = (REST_Z0 + REST_Z1)/2
    for sx in (1, -1):
        x = sx*65.0
        b = b.union(box(x - 4, x + 4, -TOP + T - 0.5, -TOP + T + 7, zc - 4.5, D - T + 0.01))
        b = b.cut(_ycyl(4.0, 8, x, -TOP - 0.5, zc))
    return b
