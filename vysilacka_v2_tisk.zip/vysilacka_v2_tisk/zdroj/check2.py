import cadquery as cq
from rounded import STYLES, body
from shade2 import *
s=dict(STYLES['S2'],key='S2')
b=body(s); bz=bezel2(s); pl=plate2(s); dL=door(-1,s); dR=door(1,s); pL=pin(-1); pR=pin(1)
for n,o in [('bezel',bz),('plate',pl),('doorL',dL),('doorR',dR),('pin',pR)]:
    bb=o.val().BoundingBox(); print(n,'valid',o.val().isValid(),'solids',len(o.solids().vals()),[round(v,1) for v in (bb.xlen,bb.ylen,bb.zlen)])
def V(a,c):
    try: return round(a.intersect(c).val().Volume(),1)
    except Exception: return 0.0
fixed=b.union(bz)
H=((0,HY,HZ),(1,HY,HZ))
def doors(ang):  # ang 0..90
    return dL.rotate((-DAX,0,DAZ),(-DAX,1,DAZ),-ang), dR.rotate((DAX,0,DAZ),(DAX,1,DAZ),ang)
def plat(a, pin_t=0):
    return pl.rotate(*H,a), pL.translate((-pin_t,0,0)).rotate(*H,a), pR.translate((pin_t,0,0)).rotate(*H,a)
def check(tag, pa, da, pin_t=0):
    P,PL,PR=plat(pa,pin_t); L,R=doors(da)
    r=dict(P_fix=V(P,fixed),L_fix=V(L,fixed),R_fix=V(R,fixed),P_L=V(P,L),P_R=V(P,R),pin_R=V(PR,R),pin_P=V(PR,P),L_R=V(L,R))
    print(tag, {k:v for k,v in r.items() if v>0} or 'OK')
check('closed',0,0)
check('plate-60',-60,0)
check('plate-130',-130,0)
for a in (30,60,90): check(f'door{a} plate-130',-130,a)
for a in (-110,-100,-95): check(f'plate{a} doors90',a,90)
check('final',-90,90)
check('final locked',-90,90,PIN_TRAVEL)
# tab inside slot check: tab top above plate top?
P,_,_=plat(-90); bbP=P.val().BoundingBox(); L,R=doors(90); bbR=R.val().BoundingBox()
print('plate open y',round(bbP.ymin,1),round(bbP.ymax,1),'z',round(bbP.zmin,1),round(bbP.zmax,1),' doorR open y',round(bbR.ymax,1),'z',round(bbR.zmin,1),round(bbR.zmax,1),'x',round(bbR.xmin,1),round(bbR.xmax,1))
