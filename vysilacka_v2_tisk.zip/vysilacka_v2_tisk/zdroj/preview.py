import trimesh, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import sys
P="/home/claude/viewer/parts/"
def show(ax, files, offs, cols, elev=35, azim=-60, title=""):
    allv=[]
    for f,o,c in zip(files,offs,cols):
        m=trimesh.load(P+f); m.apply_translation(o)
        n=m.face_normals; light=np.array([0.3,-0.5,0.8]); light/=np.linalg.norm(light)
        sh=0.35+0.65*np.clip(n@light,0,1)
        base=np.array(matplotlib.colors.to_rgb(c))
        fc=np.clip(base[None,:]*sh[:,None]+0.08,0,1)
        pc=Poly3DCollection(m.triangles,facecolors=fc,edgecolors='none'); ax.add_collection3d(pc); allv.append(m.vertices)
    v=np.vstack(allv); c=(v.max(0)+v.min(0))/2; r=(v.max(0)-v.min(0)).max()/2
    ax.set_xlim(c[0]-r,c[0]+r); ax.set_ylim(c[1]-r,c[1]+r); ax.set_zlim(c[2]-r,c[2]+r)
    ax.view_init(elev,azim); ax.set_axis_off(); ax.set_title(title)
fig=plt.figure(figsize=(16,10))
ax=fig.add_subplot(221,projection='3d'); show(ax,["A_telo_L.stl","A_telo_P.stl"],[(-40,0,0),(40,0,0)],["#888","#e8692c"],elev=-60,azim=-70,title="A zezadu")
ax=fig.add_subplot(222,projection='3d'); show(ax,["B_kridlo_L.stl","B_stred.stl","B_kridlo_P.stl"],[(-50,0,0),(0,0,0),(50,0,0)],["#e8692c","#888","#e8692c"],elev=-60,azim=-70,title="B zezadu")
ax=fig.add_subplot(223,projection='3d'); show(ax,["C_telo_L.stl","C_telo_P.stl","C_ramecek.stl","clona.stl"],[(0,0,0),(0,0,0),(0,0,30),(0,0,30)],["#888","#999","#e8692c","#555"],elev=40,azim=-60,title="C zepředu")
ax=fig.add_subplot(224,projection='3d'); show(ax,["A_telo_P.stl"],[(0,0,0)],["#888"],elev=-50,azim=-120,title="A pravá – rib detail")
plt.tight_layout(); plt.savefig("/home/claude/cad/preview.png",dpi=80)
