# Variant C with rounded styling
import math
import cadquery as cq
from model import (W, H, D, T, DISP_W, DISP_H, DISP_Y, POST_X, POST_DY, POST_D, POST_H, GIMB_X, GIMB_S,
                   SW_X, SW_Y, SW_D, ROCK_W, ROCK_H, ANT_X, ANT_D, EAR_X, EAR_Y0, EAR_Y1,
                   INSERT_D, box, cyl, seam_ribs, RIB_T, BOLT_Y)

STYLES = {
    # R = corner radius in plan view, RF = front edge fillet, RB = lid outer edge fillet,
    # RZ = bezel corner radius, ROCK = rocker switch distance from side edge
    "S1": dict(R=10, RF=3, RB=1.5, RZ=6, ROCK=30, label="Jemné"),
    "S2": dict(R=20, RF=5, RB=2.0, RZ=10, ROCK=30, label="Měkké"),
    "S3": dict(R=30, RF=6, RB=2.5, RZ=16, ROCK=40, label="Výrazné"),
}


def rbox(w, h, z0, z1, r, rf=0, top=True):
    b = box(-w/2, w/2, -h/2, h/2, z0, z1)
    if r > 0.2:
        b = b.edges("|Z").fillet(r)
    if rf > 0.2:
        b = b.edges(">Z" if top else "<Z").fillet(rf)
    return b


def boss_positions(R):
    Ri = R - T
    cx, cy = W/2 - R, H/2 - R
    ox, oy = 158.5, 73.5
    if ox > cx and oy > cy and math.hypot(ox - cx, oy - cy) > Ri - 3.5:
        k = (Ri - 3.5) / math.sqrt(2)
        ox, oy = cx + k, cy + k
    return [(sx*ox, sy*oy) for sx in (1, -1) for sy in (1, -1)]


BEZ_HOLES = [(sx*x, y) for sx in (1, -1) for x in (40, 88) for y in (67, -57)]
BEZ_BOSS_D = 7.0


def body(s):
    R, RF = s["R"], s["RF"]
    outer = rbox(W, H, 0, D, R, RF)
    if RF > 0.5:   # 45° anti-sag chamfer on the bed side of the front fillet (prints face-down)
        cham = box(-W/2, W/2, -H/2, H/2, -1, D).edges("|Z").fillet(R).edges(">Z").chamfer(RF*(2 - 2**0.5))
        outer = outer.intersect(cham)
    inner = rbox(W - 2*T, H - 2*T, -1, D - T, R - T, max(RF - T, 0))
    b = outer.cut(inner)
    for (x, y) in boss_positions(R):
        b = b.union(cyl(9, 10, x, y, 0))
    for sx in (1, -1):
        for sy in (1, -1):
            b = b.union(cyl(POST_D, POST_H + 1, sx*POST_X, DISP_Y + sy*POST_DY, D - T - POST_H))
    for (x, y) in BEZ_HOLES:
        b = b.union(cyl(9, 6.5 + 0.01, x, y, D - T - 6.5))           # inner pad for the bezel insert
    cuts = [box(-DISP_W/2, DISP_W/2, DISP_Y - DISP_H/2, DISP_Y + DISP_H/2, D - T - 1, D + 1)
            .edges("|Z").fillet(2)]
    rx = W/2 - s["ROCK"]
    for (x, y) in boss_positions(R):
        cuts.append(cyl(INSERT_D, 8, x, y, -0.5))
    for sx in (1, -1):
        for sy in (1, -1):
            cuts.append(cyl(2.6, POST_H + 1, sx*POST_X, DISP_Y + sy*POST_DY, D - T - POST_H - 0.5))
            cuts.append(cyl(3.4, T + 2, sx*GIMB_X + 27, sy*27, D - T - 1))
            cuts.append(cyl(3.4, T + 2, sx*GIMB_X - 27, sy*27, D - T - 1))
        cuts.append(box(sx*GIMB_X - GIMB_S/2, sx*GIMB_X + GIMB_S/2, -GIMB_S/2, GIMB_S/2, D - T - 1, D + 1)
                    .edges("|Z").fillet(3))
        cuts.append(cyl(SW_D, T + 2, sx*SW_X, SW_Y, D - T - 1))
        cuts.append(box(sx*rx - ROCK_W/2, sx*rx + ROCK_W/2, H/2 - T - 1, H/2 + 1, D/2 - ROCK_H/2, D/2 + ROCK_H/2))
        cuts.append(cyl(ANT_D, T + 2, sx*ANT_X, H/2 - T - 1, D/2, axis="y"))
    cuts.append(box(W/2 - T - 1, W/2 + 1, 15, 45, D/2 - 2.25, D/2 + 2.25).edges("|X").fillet(2.2))
    for (x, y) in BEZ_HOLES:
        cuts.append(cyl(INSERT_D, 6.0, x, y, D - 6.0 + 0.01))        # M3 insert pressed in from the front
    for c in cuts:
        b = b.cut(c)
    return b


def halves(b):
    out = []
    for side, (x0, x1) in ((-1, (-W, 0)), (1, (0, W))):
        p = b.intersect(box(x0, x1, -H, H, -5, D + 5))
        rib, holes = seam_ribs(0.0, side)
        p = p.union(rib)
        for h in holes:
            p = p.cut(h)
        out.append(p)
    return out


def lid(s, lap=10.0, t=3.0):
    z0 = -t
    plate = rbox(W, H, z0, 0, s["R"], s["RB"], top=False)
    for (x, y) in boss_positions(s["R"]):
        plate = plate.cut(cyl(3.4, t + 2, x, y, z0 - 1))
    for dx in (-RIB_T/2, RIB_T/2):
        for sy in (1, -1):
            plate = plate.cut(cyl(3.4, t + 2, dx, sy*BOLT_Y, z0 - 1))
    L = plate.intersect(box(-W, -lap, -H, H, z0 - 1, 1).union(box(-lap, lap, -H, H, z0 + t/2, 1)))
    Rr = plate.intersect(box(lap, W, -H, H, z0 - 1, 1).union(box(-lap, lap, -H, H, z0 - 1, z0 + t/2)))
    return L, Rr


def bezel(s):
    RF = s["RF"]
    X, Y0, t = 100.0, -62.0, 3.0
    Y1 = min(75.0, H/2 - RF - 0.5)
    z0 = D
    bz = box(-X, X, Y0, Y1, z0, z0 + t).edges("|Z").fillet(s["RZ"]).edges(">Z").fillet(1.5)
    for sx in (1, -1):
        ear = box(sx*EAR_X - 2, sx*EAR_X + 2, EAR_Y0, EAR_Y1, z0 + t - 0.5, z0 + t + 10)
        ear = ear.edges("|X").edges(">Z").fillet(1.9)
        bz = bz.union(ear)
    win = box(-DISP_W/2, DISP_W/2, DISP_Y - DISP_H/2, DISP_Y + DISP_H/2, z0 - 1, z0 + t + 1).edges("|Z").fillet(2)
    bz = bz.cut(win)
    bz = bz.cut(cyl(3.4, 200, -100, (EAR_Y0 + EAR_Y1)/2, z0 + t + 5, axis="x"))
    for sx in (1, -1):
        bz = bz.cut(cyl(SW_D, t + 2, sx*SW_X, SW_Y, z0 - 1))
    for (x, y) in BEZ_HOLES:
        bz = bz.cut(cyl(INSERT_D, 2.5, x, y, z0 - 0.01))
    return bz


def clona(s):
    CW, CD, CB = 210.0, 70.0, 55.0
    rw = {"S1": 10, "S2": 20, "S3": 30}
    c = box(0, CW, -CD/2, CD/2, 0, T)
    for x in (0, CW - T):
        wing = box(x, x + T, -CD/2, CD/2, 0, CB).edges("|X").edges("<Y").edges(">Z").fillet(rw[s["key"]])
        c = c.union(wing)
    for sg in (1, -1):
        xc = CW/2 + sg*(90 - 4 - 0.4)
        ear = box(xc - 2, xc + 2, CD/2 - 8, CD/2, 0, 13).edges("|X").edges(">Z").fillet(1.9)
        c = c.union(ear)
    c = c.cut(cyl(3.4, 200, CW/2 - 100, CD/2 - 4, 8, axis="x"))
    return c.translate((-CW/2, 0, 0))
